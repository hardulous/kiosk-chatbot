#!/bin/sh
echo "CN-Number $1" 
echo "userId $2" 
echo "SuperVisor Password $3" 
echo "Ship $4" 
echo "System $5" 
echo "MMD $6"
echo "Backup using DD"
read exit
echo "exiting".
