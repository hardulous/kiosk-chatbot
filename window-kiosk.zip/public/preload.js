const { remote } = require("electron");
window.ipcRenderer = require("electron").ipcRenderer;
